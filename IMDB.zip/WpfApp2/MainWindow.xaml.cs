﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp2
{
    public partial class MainWindow : Window
    {
        string path = "http://www.omdbapi.com/?apikey=cf381e23&";
        public MainWindow()
        {
            InitializeComponent();
        }
        public void GetDatas(string name)
        {
            WebClient webClient = new WebClient();
            var result = webClient.DownloadString(path + "t=" + name);
            dynamic data = JsonConvert.DeserializeObject(result);
            if(data.Response != "False")
                Dispatcher.Invoke(new Action(() => dataList.Items.Add(data)));

        }

        public void CreateThread(string filmname)
        {
           var thread = new Thread(
           new ThreadStart(
               () =>
               {
                   GetDatas(filmname);
               }
           ));
           thread.Start();
        }
            
        List<string> collefilms;

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (dataList != null)
            {
                dataList.Items.Clear();
            }
            string films = filmsnames.Text;
            collefilms = films.Split(',').ToList();
            foreach (var item in collefilms)
            {
                    CreateThread(item);
            }
        }
    }
}
